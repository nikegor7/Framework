<?php
namespace App;

class GreetingGenerator {
    public function getRandomGreeting() {
        $greetings = ['Hey', 'Yo', 'Aloha'];
        $greeting = $greetings[array_rand($greetings)];

        return $greeting;
    }
}
?>